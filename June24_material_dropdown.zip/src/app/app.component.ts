import { Component, OnInit } from '@angular/core';
import {JsonService} from 'src/app/json.service';
import { FormGroup,FormArray,FormBuilder,FormControl } from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  thisform : FormGroup;

  selectedBrand = [];
  selectedModel = [];
  model = [];
  color = [];
  CarBrand = [];
  multiplemodel = [];
  colors = [];
  multiColour = [];
  constructor(private jsondta : JsonService, private fb : FormBuilder){
    this.jsondta.getJsonData().subscribe(data=>{
      console.log("data",data);
      this.CarBrand = data;
    })

    this.thisform = this.fb.group({
      car : [],
      model : [],
      color : new FormArray([])
    })
  }
  ngOnInit(){
    
  }
  brandChange(e) {
    localStorage.setItem("Car_Brand",e);
    this.selectedBrand = e;
    this.CarBrand.filter(element => {
      if (element.car == e) {
        this.model = element.model;
      }
    });
    this.color = []
  }
  modelChange(evt) {
    this.multiplemodel.push(evt);
    localStorage.setItem('Car_model',evt);
      this.selectedModel = evt;
      this.model.filter(element => {
      if (element.name == evt) {
        this.color = element.color;
        console.log("color",this.color);
      }
     })
    this.multiColour.push(this.color);
    console.log("this.color",this.multiColour);
    
  }
 
  saveItem(val,i){ 
   if(localStorage.getItem('colors')){
      this.colors = JSON.parse(localStorage.getItem('colors'));
      this.colors.push(val);
      localStorage.setItem('colors',JSON.stringify(this.colors));
    }else{
      this.colors.push(val);
      localStorage.setItem('colors',JSON.stringify(this.colors));

     }
    
  }
}
