import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class JsonService {

  constructor(private http : HttpClient) { 
    this.getJsonData().subscribe(data=>{
      
    },
    error=>{
        console.log("Error to Fatch JSON data");
        
    });
  }
  getJsonData():Observable<any>{
    return this.http.get("./assets/CarData.json");
  }
}
